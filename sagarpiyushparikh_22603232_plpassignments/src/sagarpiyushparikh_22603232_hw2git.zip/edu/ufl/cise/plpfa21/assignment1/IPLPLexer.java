package edu.ufl.cise.plpfa21.assignment1;

public interface IPLPLexer {
	
	IPLPToken nextToken() throws LexicalException;
}
