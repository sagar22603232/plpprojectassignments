package edu.ufl.cise.plpfa21.assignment2;
import edu.ufl.cise.plpfa21.assignment1.CreateToken;

import java.util.ArrayList;


public class ExpressionParser {
	ArrayList<CreateToken> expressionTokens;
}
