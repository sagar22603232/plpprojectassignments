package edu.ufl.cise.plpfa21.assignment2;

public interface IPLPParser {

	void parse() throws Exception;
		

}
