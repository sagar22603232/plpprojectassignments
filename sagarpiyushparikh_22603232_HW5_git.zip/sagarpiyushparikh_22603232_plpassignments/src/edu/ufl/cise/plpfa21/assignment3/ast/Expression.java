package edu.ufl.cise.plpfa21.assignment3.ast;

public interface Expression extends IASTNode {

}
