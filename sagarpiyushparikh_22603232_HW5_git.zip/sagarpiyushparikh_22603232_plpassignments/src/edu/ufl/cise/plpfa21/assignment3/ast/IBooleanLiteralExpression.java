package edu.ufl.cise.plpfa21.assignment3.ast;

public interface IBooleanLiteralExpression extends IExpression {
	
	boolean getValue();

}
